require("./all/module.js")

//========== Setting Owner ==========//
global.owner = "6283151548024"
global.namaowner = "RIZX STR"

//======== Setting Bot & Link ========//
global.namabot = "RIZX STR" 
global.namabot2 = "RIZX STR"
global.foother = "© RIZX STR"
global.idsaluran = "not bad"
global.linkgc = 'https://chat.whatsapp.com/IDcQgBSSgSRHenCSqq3AUA'
global.linksaluran = "https://whatsapp.com/channel/0029VatBlo2CMY0L1P3VpO1l"
global.linkyt = '-'
global.linktele = "-"
global.packname = "RIZX STR"
global.author = "RIZX STR"

//========== Setting Event ==========//
global.welcome = false
global.autoread = false
global.anticall = false 
global.owneroff = false

//==== Waktu Jeda Jpm & Pushkon ====//
global.delaypushkontak = 6000
global.delayjpm = 1000

//========= Setting Url Foto =========//
//Lihat Di Folder Media!

//========== Setting Panell ==========//
global.egg = "15"
global.loc = "1"
global.domain = "https://qwertyu.ahmadpersonal.space"
global.apikey = "ptla_vtQodDaqsXg5d3TWrDNsG2SUBg2znugwwIBgRG7ZvIF"
global.capikey = "ptlc_3yxrNGMMsgM3wJ1yxSJBjyVSr8ALrx8AMv5LoUpQ50G"

//========= Setting Payment =========//
//Kalo Gak Ada Isi Aja jadi false
global.dana = "6283151548024"
global.gopay = "false"
global.ovo = "false"
global.qris = fs.readFileSync("./media/qris.jpg")
                             
//=========== Api Domain ===========//
global.zone1 = "";
global.apitoken1 = "";
global.tld1 = ""

//========== Api Domain 2 ==========//
global.zone2 = "";
global.apitoken2 = "";
global.tld2 = "";
//========== Api Domain 3 ==========//
global.zone3 = "";
global.apitoken3 = "";
global.tld3 = "";
//========== Api Domain 4 ==========//
global.zone4 = "";
global.apitoken4 = "";
global.tld4 = "";

//========= Setting Message =========//
global.msg = {
"error": "Error terjadi kesalahan",
"done": "Done Bang Rizx ✅", 
"wait": "Bot Sedang Memproses Tunggu Sebentar . . .", 
"group": "*• Group Only* Fitur Ini Hanya Untuk Di Dalam Grup!", 
"private": "*• Private Chat* Fitur Ini Hanya Untuk Didalam Private Chat!", 
"admin": "*• Admin Only* Fitur Ini Hanya Untuk Admin Grup!", 
"adminbot": "*• Bot Admin* Fitur Ini Dapat Digunakan Ketika Bot Menjadi Admin", 
"owner": "*• Owner Only* Fitur Ini Hanya Untuk Owner Bot!", 
"developer": "*• Developer Only* Fitur Ini Hanya Untuk Developer"
}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})